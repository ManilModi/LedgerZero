package org.example.model;

public class Enums {
    public enum KycStatus{
        PENDING, APPROVED, REJECTED
    }
}
