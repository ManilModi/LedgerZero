package org.example.dto;

import lombok.*;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BankHandlerReq {
    private String bankHandle;
}
