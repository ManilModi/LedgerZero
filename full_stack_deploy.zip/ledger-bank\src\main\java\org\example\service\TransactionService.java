package org.example.service;

import org.example.dto.PaymentRequest;
import org.example.dto.Response;
import org.example.dto.SmsNotificationTask;
import org.example.dto.TransactionResponse;
import org.example.enums.TransactionStatus;
import org.example.model.AccountLedger;
import org.example.model.BankAccount;
import org.example.repository.AccountRepository;
import org.example.repository.LedgerRepository;
import org.example.utils.PhoneNumberUtil;
import org.example.utils.CryptoUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional; // ✅ Spring Transactional

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Core banking transaction service. Handles debit, credit, and reversal
 * operations with proper locking.
 *
 * Locking Strategy: 1. PESSIMISTIC_WRITE lock on account row (via repository)
 * 2. @Version for optimistic locking as fallback 3. SERIALIZABLE isolation for
 * critical operations
 */
@Service
public class TransactionService {

    private static final Logger log = LoggerFactory.getLogger(TransactionService.class);

    private final AccountRepository accountRepository;
    private final LedgerRepository ledgerRepository;

    // Optional - only available when kafka.enabled=true
    private final PaymentNotificationProducer notificationProducer;

    public TransactionService(AccountRepository accountRepository,
            LedgerRepository ledgerRepository,
            @Autowired(required = false) PaymentNotificationProducer notificationProducer) {
        this.accountRepository = accountRepository;
        this.ledgerRepository = ledgerRepository;
        this.notificationProducer = notificationProducer;
    }

    /**
     * Debits amount from payer's account. ❌ WRITER: Critical Financial Op ->
     * PRIMARY
     */
    @Transactional(isolation = Isolation.SERIALIZABLE)
    public TransactionResponse debit(PaymentRequest request, String accountNumber, BigDecimal riskScore) {
        String txnId = request.getTxnId();
        log.info("Processing DEBIT: txnId={}, account={}, amount={}",
                txnId, maskAccountNumber(accountNumber), request.getAmount());

        try {
            // Idempotency check - prevent duplicate debits
            if (ledgerRepository.existsByGlobalTxnIdAndAccountNumberAndDirection(
                    txnId, accountNumber, AccountLedger.LedgerDirection.DEBIT)) {
                log.warn("Duplicate debit attempt: txnId={}", txnId);
                return buildResponse(txnId, TransactionStatus.SUCCESS, "Already processed", null, null);
            }

            // Acquire pessimistic lock on account
            BankAccount account = accountRepository.findByAccountNumberWithLock(accountNumber)
                    .orElse(null);

            if (account == null) {
                log.error("Account not found: {}", maskAccountNumber(accountNumber));
                return buildResponse(txnId, TransactionStatus.FAILED, "Account not found", null, null);
            }

            // Check frozen status
            if (account.getFrozenStatus()) {
                log.warn("Account frozen: {}", maskAccountNumber(accountNumber));
                return buildResponse(txnId, TransactionStatus.FAILED, "Account is frozen", null, null);
            }

            String HashedMpin = CryptoUtil.hashMpinWithSalt(request.getMpinHash(), account.getSalt());

            // Verify MPIN
            if (!verifyMpin(account, HashedMpin)) {
                log.warn("Invalid MPIN for account: {}", maskAccountNumber(accountNumber));
                return buildResponse(txnId, TransactionStatus.FAILED, "Invalid PIN", null, null);
            }

            // Check sufficient balance
            if (account.getCurrentBalance().compareTo(request.getAmount()) < 0) {
                log.warn("Insufficient balance: account={}, balance={}, required={}",
                        maskAccountNumber(accountNumber), account.getCurrentBalance(), request.getAmount());
                return buildResponse(txnId, TransactionStatus.FAILED, "Insufficient balance", null, null);
            }

            // Perform debit
            account.debit(request.getAmount());
            accountRepository.save(account);

            // Create ledger entry
            createLedgerEntry(txnId, accountNumber, request.getAmount(),
                    AccountLedger.LedgerDirection.DEBIT,
                    request.getPayeeVpa(),
                    account.getCurrentBalance(),
                    riskScore);

            SmsNotificationTask debitSms = new SmsNotificationTask();
            debitSms.setType("Debit");
            debitSms.setAmount(request.getAmount());
            debitSms.setRemainingBalance(account.getCurrentBalance());
            debitSms.setPhoneNumber(PhoneNumberUtil.setCode(account.getPhoneNumber()));
            debitSms.setAccountNumber(accountNumber);

            log.info("DEBIT successful: txnId={}, newBalance={}",
                    txnId, account.getCurrentBalance());

            // 📢 Publish Kafka notification for sender (payment sent confirmation)
            if (notificationProducer != null) {
                notificationProducer.publishPaymentSent(
                        txnId,
                        request.getPayerVpa(),
                        request.getPayeeVpa(),
                        request.getAmount(),
                        account.getCurrentBalance()
                );
            }

            return buildResponse(txnId, TransactionStatus.SUCCESS, "Debit successful", debitSms, null);

        } catch (ObjectOptimisticLockingFailureException e) {
            log.error("Concurrent modification detected for debit: txnId={}", txnId, e);
            return buildResponse(txnId, TransactionStatus.FAILED, "Concurrent transaction - retry", null, null);
        } catch (IllegalStateException e) {
            log.error("Debit failed: txnId={}, reason={}", txnId, e.getMessage());
            return buildResponse(txnId, TransactionStatus.FAILED, e.getMessage(), null, null);
        }
    }

    /**
     * Credits amount to payee's account. ❌ WRITER: Critical Financial Op ->
     * PRIMARY
     */
    @Transactional(isolation = Isolation.SERIALIZABLE)
    public TransactionResponse credit(PaymentRequest request, String accountNumber, BigDecimal riskScore) {
        String txnId = request.getTxnId();
        log.info("Processing CREDIT: txnId={}, account={}, amount={}",
                txnId, maskAccountNumber(accountNumber), request.getAmount());

        try {
            // Idempotency check - prevent duplicate credits
            if (ledgerRepository.existsByGlobalTxnIdAndAccountNumberAndDirection(
                    txnId, accountNumber, AccountLedger.LedgerDirection.CREDIT)) {
                log.warn("Duplicate credit attempt: txnId={}", txnId);
                return buildResponse(txnId, TransactionStatus.SUCCESS, "Already processed", null, null);
            }

            // Acquire pessimistic lock on account
            BankAccount account = accountRepository.findByAccountNumberWithLock(accountNumber)
                    .orElse(null);

            if (account == null) {
                log.error("Account not found for credit: {}", maskAccountNumber(accountNumber));
                return buildResponse(txnId, TransactionStatus.FAILED, "Account not found", null, null);
            }

            // Check frozen status (even for credits)
            if (account.getFrozenStatus()) {
                log.warn("Cannot credit frozen account: {}", maskAccountNumber(accountNumber));
                return buildResponse(txnId, TransactionStatus.FAILED, "Beneficiary account is frozen", null, null);
            }

            // Perform credit
            account.credit(request.getAmount());
            accountRepository.save(account);

            // Create ledger entry
            createLedgerEntry(txnId, accountNumber, request.getAmount(),
                    AccountLedger.LedgerDirection.CREDIT,
                    request.getPayerVpa(),
                    account.getCurrentBalance(),
                    riskScore);

            SmsNotificationTask creditSms = new SmsNotificationTask();
            creditSms.setType("Credit");
            creditSms.setAmount(request.getAmount());
            creditSms.setRemainingBalance(account.getCurrentBalance());
            creditSms.setPhoneNumber(PhoneNumberUtil.setCode(account.getPhoneNumber()));
            creditSms.setAccountNumber(accountNumber);

            log.info("CREDIT successful: txnId={}, newBalance={}",
                    txnId, account.getCurrentBalance());

            // 📢 Publish Kafka notification for receiver (payment received)
            if (notificationProducer != null) {
                notificationProducer.publishPaymentReceived(
                        txnId,
                        request.getPayeeVpa(),
                        request.getPayerVpa(),
                        request.getAmount(),
                        account.getCurrentBalance()
                );
            }

            return buildResponse(txnId, TransactionStatus.SUCCESS, "Credit successful", null, creditSms);

        } catch (ObjectOptimisticLockingFailureException e) {
            log.error("Concurrent modification detected for credit: txnId={}", txnId, e);
            return buildResponse(txnId, TransactionStatus.FAILED, "Concurrent transaction - retry", null, null);
        }
    }

    /**
     * freeze the account
     */
    @Transactional(isolation = Isolation.SERIALIZABLE)
    public Response freezeAccount(String accountNumber) {
        String txnId = "FREEZE_ACCOUNT";
        log.info("Processing FREEZE_ACCOUNT: txnId={}, account={}", txnId, maskAccountNumber(accountNumber));
        BankAccount account = accountRepository.findByAccountNumber(accountNumber).orElse(null);

        if(account == null){
            return new Response("Account not found", 400, "Account not found", null);
        }

        account.setFrozenStatus(true);
        accountRepository.save(account);
        return new Response("Account frozen successfully", 200, "Account frozen successfully", null);
    }

    /**
     * Reverses a debit operation. ❌ WRITER: Critical Financial Op -> PRIMARY
     */
    @Transactional(isolation = Isolation.SERIALIZABLE)
    public TransactionResponse reverseDebit(PaymentRequest request, String accountNumber) {
        String txnId = request.getTxnId();
        log.info("Processing REVERSAL: txnId={}, account={}, amount={}",
                txnId, maskAccountNumber(accountNumber), request.getAmount());

        try {
            // Verify original debit exists
            if (!ledgerRepository.existsByGlobalTxnIdAndAccountNumberAndDirection(
                    txnId, accountNumber, AccountLedger.LedgerDirection.DEBIT)) {
                log.warn("No debit found to reverse: txnId={}", txnId);
                return buildResponse(txnId, TransactionStatus.FAILED, "Original debit not found", null, null);
            }

            // Check if already reversed
            String reversalTxnId = txnId + "_REVERSAL";
            if (ledgerRepository.existsByGlobalTxnIdAndAccountNumberAndDirection(
                    reversalTxnId, accountNumber, AccountLedger.LedgerDirection.CREDIT)) {
                log.warn("Already reversed: txnId={}", txnId);
                return buildResponse(txnId, TransactionStatus.SUCCESS, "Already reversed", null, null);
            }

            // Acquire lock and credit back
            BankAccount account = accountRepository.findByAccountNumberWithLock(accountNumber)
                    .orElseThrow(() -> new IllegalStateException("Account not found"));

            account.credit(request.getAmount());
            accountRepository.save(account);

            // Create reversal ledger entry
            createLedgerEntry(reversalTxnId, accountNumber, request.getAmount(),
                    AccountLedger.LedgerDirection.CREDIT,
                    "REVERSAL:" + request.getPayeeVpa(),
                    account.getCurrentBalance(),
                    null);

            SmsNotificationTask reversalSms = new SmsNotificationTask();
            reversalSms.setType("Reversal");
            reversalSms.setAmount(request.getAmount());
            reversalSms.setRemainingBalance(account.getCurrentBalance());
            reversalSms.setPhoneNumber(PhoneNumberUtil.setCode(account.getPhoneNumber()));
            reversalSms.setAccountNumber(accountNumber);

            log.info("REVERSAL successful: txnId={}, newBalance={}",
                    txnId, account.getCurrentBalance());

            return buildResponse(txnId, TransactionStatus.SUCCESS, "Reversal successful", reversalSms, null);

        } catch (Exception e) {
            log.error("Reversal failed: txnId={}, error={}", txnId, e.getMessage(), e);
            return buildResponse(txnId, TransactionStatus.FAILED, "Reversal failed: " + e.getMessage(), null, null);
        }
    }

    /**
     * Creates immutable ledger entry for audit trail.
     */
    private void createLedgerEntry(String txnId, String accountNumber, BigDecimal amount,
            AccountLedger.LedgerDirection direction,
            String counterpartyVpa, BigDecimal balanceAfter,
            BigDecimal riskScore) {
        AccountLedger entry = AccountLedger.builder()
                .globalTxnId(txnId)
                .accountNumber(accountNumber)
                .amount(amount)
                .direction(direction)
                .counterpartyVpa(counterpartyVpa)
                .balanceAfter(balanceAfter)
                .riskScore(riskScore)
                .build();

        ledgerRepository.save(entry);
        log.debug("Ledger entry created: {}", entry.getLedgerId());
    }

    /**
     * Get account by account number (without lock). ✅ READ-ONLY: Simple Lookup
     * -> REPLICA
     */
    @Transactional(readOnly = true)
    public BankAccount getAccountByNumber(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber).orElse(null);
    }

    /**
     * Get paginated transaction history for an account. ✅ READ-ONLY: Heavy
     * History Query -> REPLICA
     */
    @Transactional(readOnly = true)
    public org.example.dto.Response getTransactionHistory(String accountNumber, int page, int limit) {
        org.springframework.data.domain.Pageable pageable
                = org.springframework.data.domain.PageRequest.of(page, limit);

        // This query goes to the Read Replica
        var ledgerPage = ledgerRepository.findByAccountNumberPaged(accountNumber, pageable);

        java.util.List<java.util.Map<String, Object>> transactions = ledgerPage.getContent().stream()
                .map(ledger -> {
                    java.util.Map<String, Object> map = new java.util.HashMap<>();
                    map.put("transactionId", ledger.getGlobalTxnId());
                    map.put("amount", ledger.getAmount());
                    map.put("direction", ledger.getDirection().name());
                    map.put("counterpartyVpa", ledger.getCounterpartyVpa());
                    map.put("balanceAfter", ledger.getBalanceAfter());
                    map.put("riskScore", ledger.getRiskScore());
                    map.put("timestamp", ledger.getCreatedAt().toString());
                    return map;
                })
                .collect(java.util.stream.Collectors.toList());

        java.util.Map<String, Object> data = new java.util.HashMap<>();
        data.put("transactions", transactions);
        data.put("page", page);
        data.put("limit", limit);
        data.put("total", ledgerPage.getTotalElements());
        data.put("hasMore", ledgerPage.hasNext());

        return new org.example.dto.Response("Transaction history retrieved", 200, null, data);
    }

    @Transactional(readOnly = true)
    public org.example.dto.Response getTransactionHistory(String accountNumber) {


        // This query goes to the Read Replica
        List<AccountLedger> data = ledgerRepository.findByAccountNumberOrderByCreatedAtDesc(accountNumber);

        return new org.example.dto.Response("Transaction history retrieved", 200, null, Map.of("transactions", data));
    }

    private boolean verifyMpin(BankAccount account, String providedMpinHash) {
        if (account.getMpinHash() == null || providedMpinHash == null) {
            return false;
        }
        return account.getMpinHash().equals(providedMpinHash);
    }

    private String maskAccountNumber(String accountNumber) {
        if (accountNumber == null || accountNumber.length() < 4) {
            return "****";
        }
        return "****" + accountNumber.substring(accountNumber.length() - 4);
    }

    private TransactionResponse buildResponse(String txnId, TransactionStatus status, String message, SmsNotificationTask debitSms, SmsNotificationTask creditSms) {
        return TransactionResponse.builder()
                .txnId(txnId)
                .status(status)
                .message(message)
                .creditSmsNotificationTask(creditSms)
                .debitSmsNotificationTask(debitSms)
                .build();
    }
}
